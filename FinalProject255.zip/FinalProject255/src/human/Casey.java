/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package human;

import entity.Entity;
import java.util.Random;
import main.GamePanel;

/**
 *
 * @author Yeji
 */
public class Casey extends Entity{
    
    public Casey(GamePanel gp) {
        super(gp);
        
        type = 2;
        name = "Casey Whitesell";
        speed = 3;
        
        solidArea.x = 0;
        solidArea.y = 0;
        solidArea.width = 48;
        solidArea.height = 48;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;
        
        getImage();
        
    }
    
    public void getImage() {
        // finish this after making pixel art
        up1 = setup("/casey/casey2.png", gp.tileSize, gp.tileSize);
        up2 = setup("/casey/casey3.png", gp.tileSize, gp.tileSize);
        down1 = setup("/casey/casey0.png", gp.tileSize, gp.tileSize);
        down2 = setup("/casey/casey1.png", gp.tileSize, gp.tileSize);
        left1 = setup("/casey/casey4.png", gp.tileSize, gp.tileSize);
        left2 = setup("/casey/casey5.png", gp.tileSize, gp.tileSize);
        right1 = setup("/casey/casey6.png", gp.tileSize, gp.tileSize);
        right2 = setup("/casey/casey7.png", gp.tileSize, gp.tileSize);
    }
    
    @Override
    public void setAction() {
        actionLockCounter++;
        
        if(actionLockCounter == 120) {
            Random random = new Random();
            int i = random.nextInt(100) + 1; // pick up a number from 1 to 100

            if(i <= 25) {
                direction = "up";            
            }
            if(i > 25 && i <= 50) {
                direction = "down";
            }
            if(i > 50 && i <= 75) {
                direction = "left";
            }
            if(i > 75 && i <= 100) {
                direction = "right";
            }
            
            actionLockCounter = 0;
        }
    }
    
    
}
