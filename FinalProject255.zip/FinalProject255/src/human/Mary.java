/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package human;

import entity.Entity;
import java.util.Random;
import main.GamePanel;

/**
 *
 * @author Yeji
 */
public class Mary extends Entity implements Humans {
    public Mary(GamePanel gp) {
        super(gp);
        
        type = 2;
        name = "Mary Marrison";
        speed = 3;
        
        solidArea.x = 0;
        solidArea.y = 0;
        solidArea.width = 48;
        solidArea.height = 48;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;
        
        getImage();
        
    }
    
    @Override
    public void getImage() {
        up1 = setup("/mary/mary2.png", gp.tileSize, gp.tileSize);
        up2 = setup("/mary/mary3.png", gp.tileSize, gp.tileSize);
        down1 = setup("/mary/mary0.png", gp.tileSize, gp.tileSize);
        down2 = setup("/mary/mary1.png", gp.tileSize, gp.tileSize);
        left1 = setup("/mary/mary4.png", gp.tileSize, gp.tileSize);
        left2 = setup("/mary/mary5.png", gp.tileSize, gp.tileSize);
        right1 = setup("/mary/mary6.png", gp.tileSize, gp.tileSize);
        right2 = setup("/mary/mary7.png", gp.tileSize, gp.tileSize);
    }
    
    @Override
    public void setAction() {
        actionLockCounter++;
        
        if(actionLockCounter == 120) {
            Random random = new Random();
            int i = random.nextInt(100) + 1; // pick up a number from 1 to 100

            if(i <= 25) {
                direction = "up";            
            }
            if(i > 25 && i <= 50) {
                direction = "down";
            }
            if(i > 50 && i <= 75) {
                direction = "left";
            }
            if(i > 75 && i <= 100) {
                direction = "right";
            }
            
            actionLockCounter = 0;
        }
    }
}
