/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.util.Random;
import main.GamePanel;

/**
 *
 * @author Yeji
 */
public class NPC_Helen extends Entity {
    public NPC_Helen(GamePanel gp) {
        super(gp);
        name = "Helen Tai";
        speed = 3;
        
        solidArea.x = 0;
        solidArea.y = 0;
        solidArea.width = 48;
        solidArea.height = 48;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;
        
        getImage();
        setDialogue();
    }
    
    public void getImage(){
        up1 = setup("/npc/helen6.png", gp.tileSize, gp.tileSize);
        up2 = setup("/npc/helen7.png", gp.tileSize, gp.tileSize);
        down1 = setup("/npc/helen0.png", gp.tileSize, gp.tileSize);
        down2 = setup("/npc/helen1.png", gp.tileSize, gp.tileSize);
        left1 = setup("/npc/helen2.png", gp.tileSize, gp.tileSize);
        left2 = setup("/npc/helen3.png", gp.tileSize, gp.tileSize);
        right1 = setup("/npc/helen4.png", gp.tileSize, gp.tileSize);
        right2 = setup("/npc/helen5.png", gp.tileSize, gp.tileSize);
    }
    
    public void setDialogue() {
        dialogues[0] = "oh hey, you managed to \nescape from the glass \ncontainer huh.";
        dialogues[1] = "I knew that you could figure \nit out, because your species \ntend to be smart!";
        dialogues[2] = "I wonder if I can train you \nto do stuff that I want \nyou to do... :)";
        dialogues[3] = "By the way, don't even think \nabout escaping from this \nroom because you will get in \nbig trouble!";
        dialogues[4] = "Ugh, I keep on losing my key... \nwhere did I leave that darn \nthing???";
        dialogues[5] = "oh wait, I need to update my \nlab notes too!";

    }
    
    @Override
    public void setAction() {

        actionLockCounter++;
        
        if(actionLockCounter == 120) {
            Random random = new Random();
            int i = random.nextInt(100) + 1; // pick up a number from 1 to 100

            if(i <= 25) {
                direction = "up";            
            }
            if(i > 25 && i <= 50) {
                direction = "down";
            }
            if(i > 50 && i <= 75) {
                direction = "left";
            }
            if(i > 75 && i <= 100) {
                direction = "right";
            }
            
            actionLockCounter = 0;
        }
    }
    
    @Override
    public void speak() {
        super.speak();
    }
    
    @Override
    public void changeDirection() {
        super.changeDirection();
    }
    
    
}
