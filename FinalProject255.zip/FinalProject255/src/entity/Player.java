/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import main.GamePanel;
import main.KeyHandler;
import main.UtilityTool;

/**
 *
 * @author Yeji
 */
public class Player extends Entity {
    KeyHandler keyH;
    public final int screenX;
    public final int screenY;
    public ArrayList<Entity> inventory = new ArrayList<>();
    public final int inventorySize = 5;

    public Player() {
        super(null);
        this.screenX = 0;
        this.screenY = 0;
    }
        
    public Player (GamePanel gp, KeyHandler keyH) {
        super(gp);
        this.keyH = keyH;
        
        screenX = gp.screenWidth/2 - (gp.tileSize/2);
        screenY = gp.screenHeight/2 - (gp.tileSize/2);
        
        solidArea = new Rectangle(8,16, 32, 32);
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;
        
        setDefaultValues();
        getPlayerImage();
        setItems();
    }
    
    public void setDefaultValues() {
        worldX= gp.tileSize * 8;
        worldY = gp.tileSize * 7;
        speed = 4;
        direction = "down";
    }
    
    public void setItems() {
        
    }
    
    public void move() {
        worldX = gp.tileSize * 8;
        worldY = gp.tileSize * 22;
        
    }
    
    public void getPlayerImage(){
        up1 = setup("/player/boi6.png", gp.tileSize, gp.tileSize);
        up2 = setup("/player/boi7.png", gp.tileSize, gp.tileSize);
        down1 = setup("/player/boi0.png", gp.tileSize, gp.tileSize);
        down2 = setup("/player/boi1.png", gp.tileSize, gp.tileSize);
        left1 = setup("/player/boi4.png", gp.tileSize, gp.tileSize);
        left2 = setup("/player/boi5.png", gp.tileSize, gp.tileSize);
        right1 = setup("/player/boi2.png", gp.tileSize, gp.tileSize);
        right2 = setup("/player/boi3.png", gp.tileSize, gp.tileSize);
    }
    
    public void update() {
        
        if(keyH.upPressed == true || keyH.downPressed == true || 
                keyH.leftPressed == true || keyH.rightPressed == true || 
                keyH.enterPressed == true){
            
            if(keyH.upPressed == true) {
                direction = "up";                
            }
            else if (keyH.downPressed == true){
                direction = "down";               
            }
            else if (keyH.leftPressed == true) {
                direction = "left";               
            }
            else if (keyH.rightPressed == true) {
                direction = "right";                
            }
            
            // CHECK TILE COLLISION
            collisionOn = false;
            gp.cChecker.checkTile(this);
            
            // CHECK OBJECT COLLISION
            System.out.println("object collision");
            int objIndex = gp.cChecker.checkObject(this, true);
            pickUpObject(objIndex);
            interactObj(objIndex);
            
            // CHECK NPC COLLISION
            int npcIndex = gp.cChecker.checkEntity(this, gp.npc);
            System.out.println(npcIndex + " for helen");
            interactNPC(npcIndex);
            
            // CHECK HUMAN COLLISION
            int humanIndex = gp.cChecker.checkEntity(this, gp.human);
            System.out.println(humanIndex + " for humans");
            if(humanIndex == 0 || humanIndex == 1) {
                gp.gameState = gp.gameOverState;
            }
            
            
            // CHECK EVENT
            gp.eHandler.checkEvent();
            gp.keyH.enterPressed = false;
            
            // IF COLLISION IS FALSE, PLAYER CAN MOVE
            if(collisionOn == false && keyH.enterPressed == false) {
                switch(direction) {
                    case "up":
                        worldY -= speed;
                        break;
                    case "down":
                        worldY += speed;
                        break;
                    case "left":
                        worldX -= speed;
                        break;
                    case "right":
                        worldX += speed;
                        break;
                }
            }
            
            gp.keyH.enterPressed = false;

            spriteCounter++;
            if(spriteCounter > 10) {
                if(spriteNum == 1) {
                    spriteNum = 2;
                }
                else if(spriteNum == 2) {
                    spriteNum = 1;
                }
                spriteCounter = 0;
            }
        }
        
        
    }
    
    public void pickUpObject(int i) {
        if(i == 5 || i == 6) {
            gp.obj[gp.currentMap][i] = null;
        }
    }
    
    public void interactNPC(int i) {
        if(i != 999) {
            System.out.println(gp.keyH.enterPressed);
            if(gp.keyH.enterPressed == false) {
                
                gp.gameState = gp.dialogueState;
                gp.npc[gp.currentMap][i].speak();
                gp.npc[gp.currentMap][i].changeDirection();
            }
            
        }
        gp.keyH.enterPressed = false;
    }
    
    public void interactObj(int i) {
        if(i != 999) {
            if(gp.keyH.enterPressed == true) {
                gp.gameState = gp.dialogueState;
                gp.obj[gp.currentMap][i].speak();
            }
            
        }
        
        gp.keyH.enterPressed = false;
    }
    
    public void damageHuman(int i) {
        if(i != 999) {
            gp.human[gp.currentMap][i].dying = true;
        }
    }
    
    public void draw(Graphics2D g2) {
        BufferedImage image = null;
        switch(direction) {
            case "up":
                if(spriteNum == 1){
                    image = up1;
                }
                if(spriteNum == 2){
                    image = up2;
                }
                break;
            case "down":
                if(spriteNum == 1){
                    image = down1;
                }
                if(spriteNum == 2){
                    image = down2;
                }
                break;
            case "left":
                if(spriteNum == 1){
                    image = left1;
                }
                if(spriteNum == 2){
                    image = left2;
                }
                break;
            case "right":
                if(spriteNum == 1){
                    image = right1;
                }
                if(spriteNum == 2){
                    image = right2;
                }
                break;
        }
        
        if(dying == true) {
            // human stays in place
            
        }
        g2.drawImage(image, screenX, screenY, null);
    }
}
