/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import entity.Entity;
import main.GamePanel;

/**
 *
 * @author Yeji
 */
public class OBJ_Frontdoor extends Entity {
    
    public OBJ_Frontdoor(GamePanel gp) {
        super(gp);
        name = "Frontdoor";
        down1 = setup("/objects/frontdoor.png", gp.tileSize, gp.tileSize);
        collision = true;
        
        solidArea.x = 32;
        solidArea.y = 0;
        solidArea.width = 48;
        solidArea.height = 16;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;
    }
}
