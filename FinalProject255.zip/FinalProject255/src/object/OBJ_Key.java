/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import entity.Entity;
import main.GamePanel;

/**
 *
 * @author Yeji
 */
public class OBJ_Key extends Entity {
    
    public OBJ_Key(GamePanel gp) {
        super(gp);
        name = "Key";
        down1 = setup("/objects/key.png", gp.tileSize, gp.tileSize);
        collision = true;
    }
}
