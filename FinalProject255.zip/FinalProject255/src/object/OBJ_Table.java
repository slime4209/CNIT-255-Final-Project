/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import entity.Entity;
import main.GamePanel;

/**
 *
 * @author Yeji
 */
public class OBJ_Table extends Entity{
    public OBJ_Table(GamePanel gp) {
        super(gp);
        name = "Table";
        down1 = setup("/objects/desk.png", gp.tileSize*2, gp.tileSize);
        collision = true;
        setDialogue();
    }
    
    public void setDialogue() {
        dialogues[0] = "There is an absurd amount \nof unorganized papers about \nthe reproductive system of \ntentacle aliens.";
        
    }
    
    @Override
    public void speak() { 
        super.speak();
    }
}
