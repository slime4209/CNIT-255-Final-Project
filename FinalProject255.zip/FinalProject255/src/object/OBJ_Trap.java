/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;


import entity.Entity;
import main.GamePanel;

/**
 *
 * @author Yeji
 */
public class OBJ_Trap extends Entity {
    public OBJ_Trap(GamePanel gp) {
        super(gp);
        name = "Trap";
        down1 = setup("/objects/boitrap.png", gp.tileSize*4, gp.tileSize*5);
        collision = true;
        
        
    }
}
