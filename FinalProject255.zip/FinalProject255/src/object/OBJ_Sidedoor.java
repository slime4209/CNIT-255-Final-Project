/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package object;

import entity.Entity;
import main.GamePanel;

/**
 *
 * @author Yeji
 */
public class OBJ_Sidedoor extends Entity {
    public OBJ_Sidedoor(GamePanel gp) {
        super(gp);
        name = "Sidedoor";
        down1 = setup("/objects/sidedoor.png", gp.tileSize, gp.tileSize);
        collision = true;
        
        solidArea.x = 32;
        solidArea.y = 0;
        solidArea.width = 16;
        solidArea.height = 48;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;
    }
}
