/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import entity.NPC_Helen;
import human.Casey;
import human.Mary;
import object.OBJ_Downdoor;
import object.OBJ_Frontdoor;
import object.OBJ_Sidedoor;
import object.OBJ_Table;
import object.OBJ_Trap;
import object.OBJ_Key;

/**
 *
 * @author Yeji
 */
public class AssetSetter {
    GamePanel gp;
    
    public AssetSetter(GamePanel gp) {
        this.gp = gp;
    }
    
    public void setObject() {
        int mapNum = 1;
        gp.obj[mapNum][0] = new OBJ_Trap(gp);
        gp.obj[mapNum][0].worldX = 8 * gp.tileSize;
        gp.obj[mapNum][0].worldY = 5 * gp.tileSize;
        
        gp.obj[mapNum][1] = new OBJ_Downdoor(gp);
        gp.obj[mapNum][1].worldX = 8 * gp.tileSize;
        gp.obj[mapNum][1].worldY = 11 * gp.tileSize;
        
        gp.obj[2][2] = new OBJ_Sidedoor(gp);
        gp.obj[2][2].worldX = 14 * gp.tileSize;
        gp.obj[2][2].worldY = 7 * gp.tileSize;
        
        gp.obj[3][3] = new OBJ_Frontdoor(gp); 
        gp.obj[3][3].worldX = 7 * gp.tileSize;
        gp.obj[3][3].worldY = 4 * gp.tileSize;
        
        gp.obj[3][4] = new OBJ_Frontdoor(gp); 
        gp.obj[3][4].worldX = 8 * gp.tileSize;
        gp.obj[3][4].worldY = 4 * gp.tileSize;
        
        gp.obj[mapNum][4] = new OBJ_Table(gp);
        gp.obj[mapNum][4].worldX = 1 * gp.tileSize;
        gp.obj[mapNum][4].worldY = 5 * gp.tileSize;
                
        gp.obj[mapNum][5] = new OBJ_Key(gp);
        gp.obj[mapNum][5].worldX = 2 * gp.tileSize;
        gp.obj[mapNum][5].worldY = 5 * gp.tileSize;
        
        gp.obj[2][6] = new OBJ_Key(gp);
        // for now they're on the ground but in the future, humans drop them
        gp.obj[2][6].worldX = 2 * gp.tileSize;
        gp.obj[2][6].worldY = 5 * gp.tileSize;
        
    }
    
    public void setNPC() {
        int mapNum = 1;
        gp.npc[mapNum][0] = new NPC_Helen(gp);
        gp.npc[mapNum][0].worldX = gp.tileSize*1;
        gp.npc[mapNum][0].worldY = gp.tileSize*6;
        
    }
    
    public void setHuman() {
        int mapNum = 2;
        gp.human[mapNum][0] = new Casey(gp);
        gp.human[mapNum][0].worldX = gp.tileSize*2;
        gp.human[mapNum][0].worldY = gp.tileSize*6;
        
        gp.human[mapNum][1] = new Mary(gp);
        gp.human[mapNum][1].worldX = gp.tileSize*3;
        gp.human[mapNum][1].worldY = gp.tileSize*6;
                
    }
}
